package weekEight.activity19Inheritance;
//TESTS THE EMPLOYEE CLASSES
public class Main {
    public static void main(String[] args) {
        //Employee employee1 = new Employee(12345, "John Doe");
        SalariedEmployee employee2 = new SalariedEmployee(54321, "Jane Doe", 60000);
        System.out.println(employee2.getName());
        System.out.println(employee2);
    }
}
