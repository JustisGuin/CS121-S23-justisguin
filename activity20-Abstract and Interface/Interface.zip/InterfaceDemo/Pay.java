package weekEight.activity20AbstractandInterface.InterfaceDemo;

public interface Pay
{
    double calculatePay();
}

