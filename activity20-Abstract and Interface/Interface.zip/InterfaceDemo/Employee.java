package weekEight.activity20AbstractandInterface.InterfaceDemo;

public abstract class Employee
{
    //INSTANCE VARIABLES
    private int id;
    private String name;

    //CONSTRUCTOR
    public Employee(int id, String name)
    {
        this.id = id;
        this.name = name;
    }
    //SETTERS
    public void setId(int id)
    {
        this.id = id;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    //GETTERS
    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    //METHODS
    @Override
    public String toString()
    {
        return String.format("Name: %s%nID: %d%n", name, id);
    }

    public abstract double calculatePay();
}



