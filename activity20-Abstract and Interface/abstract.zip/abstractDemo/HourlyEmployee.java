package weekEight.activity20AbstractandInterface.abstractDemo;

//           HourlyEmployee = Child Class   / Subclass   / Derived Class
//           Employee       = Parent Class /  Superclass / Base Class
//           keyword --> extends --> used to create a subclass that inherits the properties and behaviors of the parent class.
public class HourlyEmployee extends Employee
{
    //INSTANCE VARIABLES
    private double wage;
    private int hours;

    //CONSTRUCTOR
    public HourlyEmployee(int id, String name, double wage, int hours)
    {
        super(id, name);
        this.wage = wage;
        this.hours = hours;
    }
    //SETTERS
    public void setWage(double wage)
    {
        this.wage = wage;
    }
    public void setHours(int hours)
    {
        this.hours = hours;
    }

    //GETTERS
    public double getWage()
    {
        return wage;
    }
    public int getHours()
    {
        return hours;
    }

    //METHODS

    @Override
    public String toString()
    {
        return super.toString() + String.format("Wage: %.2f%nHours: %d%n",
                getWage(), getHours());
    }

    @Override
    public double calculatePay()
    {
        return wage * hours;
    }
}

