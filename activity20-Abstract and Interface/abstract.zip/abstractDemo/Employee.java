package weekEight.activity20AbstractandInterface.abstractDemo;
// Abstract Class
/*
* Abstraction: in Java  is the process of hiding the implementation details of a class and
* exposing only the essential features and behaviors that are relevant to the user. It allows
* programmers to create  complex systems by breaking them down into smaller, more manageable parts that
* can be used independently of the implementation details.
*
* Abstraction is achieved through the use of abstract classes and interfaces.
*  */
public abstract class Employee
{
    //INSTANCE VARIABLES/ Fields
    private int id;
    private String name;

   //CONSTRUCTOR
    public Employee(int id, String name)
    {
        this.id = id;
        this.name = name;
    }
  //SETTERS
    public void setId(int id)
    {
        this.id = id;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    //GETTERS
    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }
    //METHOD
    @Override
    public String toString()
    {
        return String.format("Name: %s%nID: %d%n", name, id);
    }

    //An Abstract Method
    // is declared with the abstract keyword and without an implementation
    // Declared but not implemented in the abstract class.
    // The implementation is left up to the subclasses that extend the abstract class.
    public abstract double calculatePay();
}
