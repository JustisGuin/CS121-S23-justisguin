package weekEight.activity20AbstractandInterface.abstractDemo;

public class SalariedEmployee extends Employee
{
    //INSTANCE VARIABLE
    private double salary;

    //CONSTRUCTOR
    public SalariedEmployee(int id, String name, double salary)
    {
        super(id, name);
        this.salary = salary;
    }
    //SETTER
    public void setSalary(double salary)
    {
        this.salary = salary;
    }
    //GETTER
    public double getSalary()
    {
        return salary;
    }

    //METHODS
    @Override
    public String toString()
    {
        return String.format("Name: %s%nID: %d%nSalary: %.2f%n",
                getName(), getId(), getSalary());
    }

    @Override
    public double calculatePay()
    {
        return salary/52;
    }
}

