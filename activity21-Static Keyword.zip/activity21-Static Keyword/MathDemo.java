package weekEight.activity21statickeyword;

public class MathDemo {
    public static void main(String[] args) {
        System.out.println(Math.max(89, 71));
        System.out.println(Math.min(89, 71));
        System.out.println(Math.abs(-20));
        System.out.println(Math.round(3.14159265359));

    }
}
